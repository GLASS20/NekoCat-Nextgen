@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.client.gui.stream;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;