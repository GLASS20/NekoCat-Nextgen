@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.server;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;