@ParametersAreNonnullByDefault
@MethodsReturnNonnullByDefault
package net.minecraft.server.integrated;

import mcp.MethodsReturnNonnullByDefault;
import javax.annotation.ParametersAreNonnullByDefault;